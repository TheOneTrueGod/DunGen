import Game, os, Units, Code.Units.Equipment as Equipment
from Globals import *

import pickle
from GUI import Application, View, Document, Window, Cursor, rgb, Button, Container, FileDialogs, TextField, Font, Column, Image
from GUI.Files import FileType, DirRef
from GUI.Geometry import offset_rect, rect_sized
from GUI.Geometry import pt_in_rect, offset_rect, rects_intersect
from GUI.StdColors import black, red, yellow

from Code.UI.CharacterPanel import *
from Code.UI.Components import *

WINDOWWIDTH = 600
WINDOWHEIGHT = 600
AutoLogIn = True
class MordorApp(Application):
	def __init__(self):
		Application.__init__(self)
	
	def open_app(self):
		self.new_cmd()

	def make_document(self, fileref):
		return Document()
		
	def playGame(self):
		if PLAYERFILES[0] or PLAYERFILES[1]:
			self.window.hide()
			MG = Game.MainGame()
			result = MG.playStreamingGame([self.leftView.model.character, self.rightView.model.character])
			if result == "QUIT":
				self._quit()
			else:
				self.window.show()
			self.leftView.model.characterUpdated()
			self.rightView.model.characterUpdated()
			
	def reloadCharacters(self):
		self.leftView.model.reloadCharacter()
		self.rightView.model.reloadCharacter()

	def make_window(self, document):
		win = Window(size = (WINDOWWIDTH, WINDOWHEIGHT), resizable=False)
		self.window = win
		win.reloadCharacters = self.reloadCharacters
		btn1 = Button(title = "Start!", action = self.playGame, style = 'default')
		btn1.position = ((WINDOWWIDTH - btn1.width) / 2, WINDOWHEIGHT - btn1.height - 5)
		
		newChar = CharacterDoc()
		newChar.character = None
		self.leftView = CharacterPanel(model = newChar, size = (WINDOWWIDTH / 2 - 5, WINDOWHEIGHT - 100))
		newChar = CharacterDoc()
		newChar.character = None
		self.rightView = CharacterPanel(model = newChar, size = (WINDOWWIDTH / 2 - 5, WINDOWHEIGHT - 100))
		self.leftView.setupComponents()
		self.rightView.setupComponents()
		self.rightView.playerNum = 1
		win.place(self.leftView, left=3, top=3)
		win.place(self.rightView, right=-3, top=3)
		#leftView.position = (0, 0)
		#rightView.position = (WINDOWWIDTH / 2, 0)
		
		win.add(btn1)
		win.show()
		
		if AutoLogIn:
			self.leftView.autoLogIn()
			
class CharacterDoc(Document):
	character = None
	path = ""
	def new_contents(self):
		self.character = None

	def read_contents(self, file):
		self.character = pickle.load(file)

	def write_contents(self, file):
		#if self.character:
		#	self.character.saveToFile()
		pass
			
	def saveCharacter(self):
		if self.character:
			self.character.saveToFile(self.path)
			
	def loadCharacter(self, path):
		if self.character:
			del self.character
		self.path = path
		self.character = pickle.load(open(path))
		self.notify_views('characterChanged', self.character)
		
	def reloadCharacter(self):
		if self.character:
			self.loadCharacter(self.path)
		
	def setPicture(self, pic):
		self.character.setPicture(pic)
		self.notify_views('characterChanged', self.character)
		self.saveCharacter()
		
	def equipItem(self, slotNum):
		if self.character:
			self.character.equipItem(slotNum)
			self.notify_views('characterChanged', self.character)
			self.saveCharacter()
			
	def characterUpdated(self):
		self.notify_views('characterChanged', self.character)
			
	def unequipItem(self, slotNum):
		if self.character:
			self.character.unequipItem(slotNum)
			self.notify_views('characterChanged', self.character)
			self.saveCharacter()
	

MordorApp().run()